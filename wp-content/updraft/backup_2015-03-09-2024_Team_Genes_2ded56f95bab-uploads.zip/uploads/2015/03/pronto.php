<?php
/*
Plugin Name: Pronto
Description: Custom Plugin for Pronto Integration
Author: Dan
Version: 1.0
*/

function pronto_add_dependency() {
	if(is_admin()) {
		return;
	}

	?>
	<link rel="stylesheet" href="http://imo.wpstaging.co.uk/app/concat.min.css"/>
	<script type="text/javascript" src="http://imo.wpstaging.co.uk/app/app.anno.min.js"></script>
	<?php
}
add_action( 'wp_head', 'pronto_add_dependency' );
